package com.example.simonsaysproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import java.util.Random;

public class Sequence extends AppCompatActivity {

    public int Score;

    public int[] Sequence = new int[1];
    private Button blueBtn,redBtn,yellowBtn,greenBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sequence);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

        blueBtn = findViewById(R.id.Blue);
        redBtn = findViewById(R.id.Red);
        yellowBtn = findViewById(R.id.Yellow);
        greenBtn = findViewById(R.id.Orange);

        // blueBtn.setVisibility(View.INVISIBLE);
        // redBtn.setVisibility(View.INVISIBLE);
        //yellowBtn.setVisibility(View.INVISIBLE);
        // orangeBtn.setVisibility(View.INVISIBLE);

        for (int i = 0; i < Sequence.length; i++) {

            Random rand = new Random();
            int rand_int1 = rand.nextInt(4);

            Sequence[i]= rand_int1;
            // Generate random integers in range 0 to 999
        }
        ReadSequence();
    }

    public void ReadSequence() {


        for (int i = 0; i < Sequence.length; i++) {

            int seqVal = Sequence[i];

            if (seqVal == 0) {

                Animation animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

                blueBtn.setBackgroundColor(Color.BLUE);
                blueBtn.startAnimation(animFadeIn);

            }

            if (seqVal == 1) {

                Animation animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

                redBtn.setBackgroundColor(Color.RED);
                redBtn.startAnimation(animFadeIn);

            }

            if (seqVal == 2) {

                Animation animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

                yellowBtn.setBackgroundColor(Color.YELLOW);
                yellowBtn.startAnimation(animFadeIn);

            }

            if (seqVal == 3) {

                Animation animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

                greenBtn.setBackgroundColor(Color.GREEN);
                greenBtn.startAnimation(animFadeIn);

            }
        }
    }

    public void onClick(View view) {
        Intent intent=new Intent(this, MainActivity2.class);
        intent.putExtra( "score", Score );
        intent.putExtra("Sequence", Sequence);
        startActivity(intent);
    }
}
