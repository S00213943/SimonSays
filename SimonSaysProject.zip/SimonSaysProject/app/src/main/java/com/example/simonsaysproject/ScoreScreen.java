package com.example.simonsaysproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ScoreScreen extends AppCompatActivity {

    public int Score;

    public int[] Sequence;
    TextView scoreText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_screen);

        Score = getIntent().getIntExtra( "score", Score );
        Sequence = getIntent().getIntArrayExtra("Sequence");
        scoreText = findViewById(R.id.Score);

        String scoreStr = Integer.toString(Score);
        scoreText.setText(scoreStr);
    }

    public void keepPlaying(View view) {
        Intent intent=new Intent(this, OngoingGame.class);
        intent.putExtra( "score", Score );
        intent.putExtra( "Sequence", Sequence );
        startActivity(intent);
    }

    public void finish(View view) {
        Intent intent=new Intent(this, enterScore.class);
        intent.putExtra( "score", Score );
        startActivity(intent);
    }

}