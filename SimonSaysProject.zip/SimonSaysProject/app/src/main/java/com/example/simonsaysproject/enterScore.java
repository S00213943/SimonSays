package com.example.simonsaysproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class enterScore extends AppCompatActivity {

    public int Score;
    TextView scoreText;
    EditText nameText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_score);

        Score = getIntent().getIntExtra( "score", Score );
        scoreText = findViewById(R.id.scoreText);
        nameText = findViewById(R.id.playerNameText);

        String scoreStr = Integer.toString(Score);
        scoreText.setText(scoreStr);
    }

    public void onClick(View view) {
        String name = nameText.getText().toString();
        Intent intent=new Intent(this, MainActivity2.class);
        intent.putExtra( "score", Score );
        intent.putExtra( "name", name );
        startActivity(intent);
    }
}
