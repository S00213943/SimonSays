package com.example.simonsaysproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity implements SensorEventListener {
    private final double HI_STEP = 11.0;     // upper mag limit
    private final double LO_STEP = 8.0;      // lower mag limit
    boolean highLimit = false;      // detect high limit
    int counter = 0;                // step counter
    public int Score;

    TextView tvx, tvy, tvz, tvMag, tvSteps;
    private Button blueBtn, redBtn, yellowBtn, greenBtn,answerBtn,finishBtn;


    private SensorManager mSensorManager;
    private Sensor mSensor;

    public int arrayLength;

    public int[] Sequence;
    public int[] PlayerSequence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        blueBtn = findViewById(R.id.blue);
        redBtn = findViewById(R.id.red);
        yellowBtn = findViewById(R.id.yellow);
        greenBtn = findViewById(R.id.orange);

        answerBtn = findViewById(R.id.Continue);
        finishBtn = findViewById(R.id.Finish);

        tvx = findViewById(R.id.tvX);
        tvy = findViewById(R.id.tvY);
        tvz = findViewById(R.id.tvZ);
        tvMag = findViewById(R.id.tvMag);
        tvSteps = findViewById(R.id.tvSteps);

        // we are going to use the sensor service
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        Sequence = getIntent().getIntArrayExtra("Sequence");
        arrayLength = Sequence.length;
        PlayerSequence = new int [arrayLength];
    }

    /*
     * When the app is brought to the foreground - using app on screen
     */
    protected void onResume() {
        super.onResume();
        // turn on the sensor
        mSensorManager.registerListener(this, mSensor,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    /*
     * App running but not on screen - in the background
     */
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);    // turn off listener to save power
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        tvx.setText(String.valueOf(x));
        tvy.setText(String.valueOf(y));
        tvz.setText(String.valueOf(z));

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // not used
    }

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    public void RegisterChoice(View view) {

        double X = Double.parseDouble(tvx.getText().toString());
        double Y = Double.parseDouble(tvy.getText().toString());

        for (int i = 0; i < Sequence.length; i++) {

            if (X >= 5) {

                redBtn.setText("Blue");
                redBtn.setBackgroundColor(Color.RED);
                PlayerSequence[i] = 1;
            } else if (X <= -5) {

                blueBtn.setText("Blue");
                blueBtn.setBackgroundColor(Color.BLUE);
                PlayerSequence[i] = 0;
            } else if (Y >= 5) {
                greenBtn.setText("Blue");
                greenBtn.setBackgroundColor(Color.GREEN);
                PlayerSequence[i] = 3;
            } else if (Y <= -5) {

                yellowBtn.setText("Blue");
                yellowBtn.setBackgroundColor(Color.YELLOW);
                PlayerSequence[i] = 2;
            }
        }
    }

    public void CheckAnswer(View view) {

        for (int i = 0; i < Sequence.length; i++) {

            if (Sequence[i] == PlayerSequence[i]) {
                Toast.makeText(this, "Correct", Toast.LENGTH_LONG).show();
                Score = Score + 1;
            } else {
                Toast.makeText(this, "Wrong", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void finishRun(View view) {

        Intent intent = new Intent(getApplicationContext(), ScoreScreen.class);
        intent.putExtra( "score", Score );
        intent.putExtra("Sequence", Sequence);
        startActivity(intent);
    }
}
