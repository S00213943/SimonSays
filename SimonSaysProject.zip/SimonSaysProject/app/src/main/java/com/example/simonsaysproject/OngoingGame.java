package com.example.simonsaysproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import java.util.Random;

public class OngoingGame extends AppCompatActivity {

    public int Score;

    private Button blueBtn,redBtn,yellowBtn,greenBtn;

    public int[] Sequence;
    public int[] nextSequence;

    public int arrayLength;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sequence);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        Score = getIntent().getIntExtra( "score", Score );
        Sequence = getIntent().getIntArrayExtra("Sequence");

        arrayLength = Sequence.length;
        nextSequence = new int [arrayLength + 1];

        blueBtn = findViewById(R.id.Blue);
        redBtn = findViewById(R.id.Red);
        yellowBtn = findViewById(R.id.Yellow);
        greenBtn = findViewById(R.id.Orange);

        // blueBtn.setVisibility(View.INVISIBLE);
        // redBtn.setVisibility(View.INVISIBLE);
        //yellowBtn.setVisibility(View.INVISIBLE);
        // orangeBtn.setVisibility(View.INVISIBLE);

        for (int i = 0; i < nextSequence.length; i++) {

            Random rand = new Random();
            int rand_int1 = rand.nextInt(4);

            nextSequence[i]= rand_int1;
            // Generate random integers in range 0 to 999
        }

        ReadSequence();

    }

    public void ReadSequence() {


        for (int i = 0; i < nextSequence.length; i++) {

            int wait;
            int seqVal = nextSequence[i];

            if (seqVal == 0) {
                wait = 0;
                Animation animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

                blueBtn.setBackgroundColor(Color.BLUE);
                blueBtn.startAnimation(animFadeIn);

                while(wait < 3000){
                    wait++;
                }

            }

            if (seqVal == 1) {
                wait = 0;
                Animation animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

                redBtn.setBackgroundColor(Color.RED);
                redBtn.startAnimation(animFadeIn);

                while(wait < 3000){
                    wait++;
                }
            }

            if (seqVal == 2) {
                wait = 0;
                Animation animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

                yellowBtn.setBackgroundColor(Color.YELLOW);
                yellowBtn.startAnimation(animFadeIn);

                while(wait < 3000){
                    wait++;
                }
            }

            if (seqVal == 3) {
                wait = 0;
                Animation animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                Animation animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);

                greenBtn.setBackgroundColor(Color.GREEN);
                greenBtn.startAnimation(animFadeIn);

                while(wait < 3000){
                    wait++;
                }
            }
        }
    }

    public void onClick(View view) {
        Intent intent=new Intent(this, MainActivity2.class);
        intent.putExtra( "score", Score );
        intent.putExtra("Sequence", nextSequence);
        startActivity(intent);
    }
}
